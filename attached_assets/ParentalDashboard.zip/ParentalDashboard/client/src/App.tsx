import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/context/AuthContext";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import LoginPage from "@/pages/login";
import LocationPage from "@/pages/location";
import BrowsingHistoryPage from "@/pages/browsing-history";
import SiteBlockerPage from "@/pages/site-blocker";
import ScreenViewPage from "@/pages/screen-view";
import AudioListenerPage from "@/pages/audio-listener";
import LandingPage from "@/pages/landing";
import AboutPage from "@/pages/about";
import FeaturesPage from "@/pages/features";
import PricingPage from "@/pages/pricing";
import ContactPage from "@/pages/contact";
import SettingsPage from "@/pages/settings";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/features" component={FeaturesPage} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/location" component={LocationPage} />
      <Route path="/browsing-history" component={BrowsingHistoryPage} />
      <Route path="/site-blocker" component={SiteBlockerPage} />
      <Route path="/screen-view" component={ScreenViewPage} />
      <Route path="/audio-listener" component={AudioListenerPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
