import React from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Shield } from "lucide-react";

const AboutPage = () => {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <header className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-primary" />
              <span 
                className="ml-2 text-2xl font-bold text-gray-900 cursor-pointer" 
                onClick={() => setLocation("/")}
              >
                SafeGuard
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setLocation("/about")} 
                className="text-sm font-medium text-primary"
              >
                About
              </button>
              <button 
                onClick={() => setLocation("/features")} 
                className="text-sm font-medium text-gray-500 hover:text-gray-900"
              >
                Features
              </button>
              <button 
                onClick={() => setLocation("/pricing")} 
                className="text-sm font-medium text-gray-500 hover:text-gray-900"
              >
                Pricing
              </button>
              <button 
                onClick={() => setLocation("/contact")} 
                className="text-sm font-medium text-gray-500 hover:text-gray-900"
              >
                Contact
              </button>
              <Button 
                onClick={() => setLocation("/login")} 
                className="flex items-center ml-4"
              >
                Parent Dashboard
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* About Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-6 text-center">About SafeGuard</h1>
          
          <div className="prose prose-blue mx-auto">
            <h2>Our Mission</h2>
            <p>
              At SafeGuard, our mission is to create a safer digital environment for children. We believe that technology should enrich children's lives without exposing them to inappropriate content or excessive screen time. Our comprehensive parental control solution empowers parents to guide their children's digital journey responsibly.
            </p>
            
            <h2>Our Story</h2>
            <p>
              SafeGuard was founded in 2022 by a group of parents who were also technology professionals. Concerned about their own children's digital safety and well-being, they combined their expertise to create a solution that balances protection with privacy and respect for children's autonomy.
            </p>
            <p>
              What began as a passion project quickly evolved into a comprehensive platform that now helps thousands of families navigate the digital world safely.
            </p>
            
            <h2>Our Values</h2>
            <ul>
              <li><strong>Safety First:</strong> We prioritize children's digital safety above all else.</li>
              <li><strong>Privacy:</strong> We respect user privacy and maintain strict data protection standards.</li>
              <li><strong>Balance:</strong> We believe in balanced technology use that enhances rather than dominates life.</li>
              <li><strong>Empowerment:</strong> We empower parents with tools and knowledge to make informed decisions.</li>
              <li><strong>Innovation:</strong> We continuously improve our solutions to address evolving digital challenges.</li>
            </ul>
            
            <h2>Our Approach</h2>
            <p>
              SafeGuard takes a holistic approach to digital safety. Rather than simply blocking content, we provide parents with insights into their children's digital activities and tools to set healthy boundaries. Our platform is designed to grow with your family, adapting to children's changing needs as they mature.
            </p>
            
            <h2>Our Team</h2>
            <p>
              Our diverse team brings together expertise in cybersecurity, child psychology, user experience design, and software development. This interdisciplinary approach ensures that SafeGuard addresses the technical, emotional, and developmental aspects of children's digital safety.
            </p>
            
            <div className="my-8 text-center">
              <Button 
                onClick={() => setLocation("/login")} 
                className="px-8 py-3 text-base font-medium rounded-md text-white bg-primary hover:bg-blue-700"
              >
                Start Protecting Your Children Today
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <Shield className="h-8 w-8 text-white" />
              <span className="ml-2 text-xl font-bold">SafeGuard</span>
            </div>
            <div className="flex space-x-6">
              <button onClick={() => setLocation("/about")} className="text-gray-300 hover:text-white">About</button>
              <button onClick={() => setLocation("/features")} className="text-gray-300 hover:text-white">Features</button>
              <button onClick={() => setLocation("/pricing")} className="text-gray-300 hover:text-white">Pricing</button>
              <button onClick={() => setLocation("/contact")} className="text-gray-300 hover:text-white">Contact</button>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-700 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400">&copy; 2023 SafeGuard. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <p className="text-gray-400">Protecting children in the digital age</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default AboutPage;
