import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  UserCredential,
  onAuthStateChanged,
  User
} from "firebase/auth";

// Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyDj61LRjkKRUeYHYfcPQVszKWRpW8d-YgI",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "safeguard-parental.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "safeguard-parental",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "safeguard-parental.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "893267018778",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:893267018778:web:b9d9b9b9d9b9b9b9d9b9b9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Authentication Functions
export const loginWithEmail = async (email: string, password: string): Promise<UserCredential> => {
  return signInWithEmailAndPassword(auth, email, password);
};

export const registerWithEmail = async (email: string, password: string): Promise<UserCredential> => {
  return createUserWithEmailAndPassword(auth, email, password);
};

export const logoutUser = async (): Promise<void> => {
  return signOut(auth);
};

export const getCurrentUser = (): User | null => {
  return auth.currentUser;
};

export const onAuthChanged = (callback: (user: User | null) => void): () => void => {
  return onAuthStateChanged(auth, callback);
};

export default app;
