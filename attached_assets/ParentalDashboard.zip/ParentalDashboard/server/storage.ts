import { 
  users, 
  children, 
  activities, 
  blockedSites, 
  deviceSettings, 
  type User, 
  type InsertUser, 
  type Child, 
  type InsertChild, 
  type Activity, 
  type InsertActivity, 
  type BlockedSite, 
  type InsertBlockedSite, 
  type DeviceSettings, 
  type InsertDeviceSettings 
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Child operations
  getChild(id: number): Promise<Child | undefined>;
  getAllChildren(): Promise<Child[]>;
  createChild(child: InsertChild): Promise<Child>;
  updateChild(id: number, data: Partial<InsertChild>): Promise<Child>;
  deleteChild(id: number): Promise<void>;

  // Activity operations
  getActivity(id: number): Promise<Activity | undefined>;
  getActivitiesByChildId(childId: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Blocked site operations
  getBlockedSite(id: number): Promise<BlockedSite | undefined>;
  getBlockedSitesByChildId(childId: number): Promise<BlockedSite[]>;
  createBlockedSite(site: InsertBlockedSite): Promise<BlockedSite>;
  updateBlockedSite(id: number, data: Partial<InsertBlockedSite>): Promise<BlockedSite>;
  deleteBlockedSite(id: number): Promise<void>;

  // Device settings operations
  getDeviceSettings(id: number): Promise<DeviceSettings | undefined>;
  getDeviceSettingsByChildId(childId: number): Promise<DeviceSettings | undefined>;
  createDeviceSettings(settings: InsertDeviceSettings): Promise<DeviceSettings>;
  updateDeviceSettings(id: number, data: Partial<InsertDeviceSettings>): Promise<DeviceSettings>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private children: Map<number, Child>;
  private activities: Map<number, Activity>;
  private blockedSites: Map<number, BlockedSite>;
  private deviceSettings: Map<number, DeviceSettings>;

  private userIdCounter: number;
  private childIdCounter: number;
  private activityIdCounter: number;
  private blockedSiteIdCounter: number;
  private deviceSettingsIdCounter: number;

  constructor() {
    this.users = new Map();
    this.children = new Map();
    this.activities = new Map();
    this.blockedSites = new Map();
    this.deviceSettings = new Map();

    this.userIdCounter = 1;
    this.childIdCounter = 1;
    this.activityIdCounter = 1;
    this.blockedSiteIdCounter = 1;
    this.deviceSettingsIdCounter = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample parent
    const sampleUser: InsertUser = {
      username: "parent",
      password: "password123",
      email: "parent@example.com",
      displayName: "Sarah Johnson"
    };
    const parent = this.createUser(sampleUser);

    // Create sample children
    const emma: InsertChild = {
      name: "Emma",
      age: 12,
      deviceId: "device-123",
      parentId: parent.id
    };
    const michael: InsertChild = {
      name: "Michael",
      age: 9,
      deviceId: "device-456",
      parentId: parent.id
    };
    const emmaChild = this.createChild(emma);
    const michaelChild = this.createChild(michael);

    // Create sample activities for Emma
    const activities: InsertActivity[] = [
      {
        childId: emmaChild.id,
        activityType: "app_usage",
        title: "App Usage",
        description: "Opened YouTube app for 15 minutes",
        metadata: { appName: "YouTube", duration: 15 }
      },
      {
        childId: emmaChild.id,
        activityType: "blocked_content",
        title: "Blocked Content",
        description: "Attempted to access blocked site: social-media-x.com",
        metadata: { url: "social-media-x.com", timestamp: new Date().toISOString() }
      },
      {
        childId: emmaChild.id,
        activityType: "location_update",
        title: "Location Update",
        description: "Arrived at Oak Hill School",
        metadata: { 
          location: "Oak Hill School", 
          coordinates: { lat: 37.7749, lng: -122.4194 }, 
          timestamp: new Date().toISOString() 
        }
      },
      {
        childId: emmaChild.id,
        activityType: "device_status",
        title: "Device Status",
        description: "Device battery at 85%",
        metadata: { batteryLevel: 85, isCharging: false }
      }
    ];

    activities.forEach(activity => this.createActivity(activity));

    // Create sample blocked sites
    const blockedSitesList: InsertBlockedSite[] = [
      { url: "https://www.socialmedia.com", childId: emmaChild.id, isActive: true },
      { url: "https://www.games.com", childId: emmaChild.id, isActive: true },
      { url: "https://www.adultcontent.com", childId: emmaChild.id, isActive: true },
      { url: "https://www.gambling.com", childId: emmaChild.id, isActive: false }
    ];

    blockedSitesList.forEach(site => this.createBlockedSite(site));

    // Create device settings
    const emmaSettings: InsertDeviceSettings = {
      childId: emmaChild.id,
      internetAccess: true,
      appInstallation: false,
      screenTimeBonus: false
    };

    const michaelSettings: InsertDeviceSettings = {
      childId: michaelChild.id,
      internetAccess: true,
      appInstallation: true,
      screenTimeBonus: true
    };

    this.createDeviceSettings(emmaSettings);
    this.createDeviceSettings(michaelSettings);
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  // Child operations
  async getChild(id: number): Promise<Child | undefined> {
    return this.children.get(id);
  }

  async getAllChildren(): Promise<Child[]> {
    return Array.from(this.children.values());
  }

  async createChild(child: InsertChild): Promise<Child> {
    const id = this.childIdCounter++;
    const newChild: Child = { ...child, id };
    this.children.set(id, newChild);
    return newChild;
  }

  async updateChild(id: number, data: Partial<InsertChild>): Promise<Child> {
    const child = await this.getChild(id);
    if (!child) {
      throw new Error(`Child with ID ${id} not found`);
    }
    
    const updatedChild: Child = { ...child, ...data };
    this.children.set(id, updatedChild);
    return updatedChild;
  }

  async deleteChild(id: number): Promise<void> {
    if (!this.children.has(id)) {
      throw new Error(`Child with ID ${id} not found`);
    }
    this.children.delete(id);
  }

  // Activity operations
  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }

  async getActivitiesByChildId(childId: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.childId === childId)
      .sort((a, b) => {
        const dateA = new Date(a.timestamp).getTime();
        const dateB = new Date(b.timestamp).getTime();
        return dateB - dateA; // Sort by newest first
      });
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const newActivity: Activity = { 
      ...activity, 
      id, 
      timestamp: activity.timestamp || new Date() 
    };
    this.activities.set(id, newActivity);
    return newActivity;
  }

  // Blocked site operations
  async getBlockedSite(id: number): Promise<BlockedSite | undefined> {
    return this.blockedSites.get(id);
  }

  async getBlockedSitesByChildId(childId: number): Promise<BlockedSite[]> {
    return Array.from(this.blockedSites.values())
      .filter(site => site.childId === childId);
  }

  async createBlockedSite(site: InsertBlockedSite): Promise<BlockedSite> {
    const id = this.blockedSiteIdCounter++;
    const newSite: BlockedSite = { ...site, id };
    this.blockedSites.set(id, newSite);
    return newSite;
  }

  async updateBlockedSite(id: number, data: Partial<InsertBlockedSite>): Promise<BlockedSite> {
    const site = await this.getBlockedSite(id);
    if (!site) {
      throw new Error(`Blocked site with ID ${id} not found`);
    }
    
    const updatedSite: BlockedSite = { ...site, ...data };
    this.blockedSites.set(id, updatedSite);
    return updatedSite;
  }

  async deleteBlockedSite(id: number): Promise<void> {
    if (!this.blockedSites.has(id)) {
      throw new Error(`Blocked site with ID ${id} not found`);
    }
    this.blockedSites.delete(id);
  }

  // Device settings operations
  async getDeviceSettings(id: number): Promise<DeviceSettings | undefined> {
    return this.deviceSettings.get(id);
  }

  async getDeviceSettingsByChildId(childId: number): Promise<DeviceSettings | undefined> {
    for (const settings of this.deviceSettings.values()) {
      if (settings.childId === childId) {
        return settings;
      }
    }
    return undefined;
  }

  async createDeviceSettings(settings: InsertDeviceSettings): Promise<DeviceSettings> {
    const id = this.deviceSettingsIdCounter++;
    const newSettings: DeviceSettings = { ...settings, id };
    this.deviceSettings.set(id, newSettings);
    return newSettings;
  }

  async updateDeviceSettings(id: number, data: Partial<InsertDeviceSettings>): Promise<DeviceSettings> {
    const settings = await this.getDeviceSettings(id);
    if (!settings) {
      throw new Error(`Device settings with ID ${id} not found`);
    }
    
    const updatedSettings: DeviceSettings = { ...settings, ...data };
    this.deviceSettings.set(id, updatedSettings);
    return updatedSettings;
  }
}

export const storage = new MemStorage();
